var data = {
  username: "0",
  password: "0",
}
// Function to open and close menu
function openMenu() {
  document.getElementById("menu").style.display = "block";
  document.getElementById("menuOverlay").style.display = "block";
}
 
function closeMenu() {
  document.getElementById("menu").style.display = "none";
  document.getElementById("menuOverlay").style.display = "none";
}
// Function to submit user data
function submit(){
  if (document.getElementById("username").value.length < 4 || document.getElementById("username").value.length > 8){
    document.getElementById("inputError").textContent = "Please follow username guidelines";
  }
  else if(document.getElementById("password").value.length < 8){
    document.getElementById("inputError").textContent = "Please follow password guidelines";
  }else{
    unHide();
  }
}
function unHide(){
  data.username = document.getElementById("username").value;
  data.password = document.getElementById("password").value;
  document.getElementById("inputError").style.display = "none";
    document.getElementById("username").style.display = "none";
      document.getElementById("password").style.display = "none";
  document.getElementById("hide").style.display = "block";
    document.getElementById("cancel").style.display = "none";
      document.getElementById("submit").style.display = "none";
        document.getElementById("usernameLabel").style.display = "none";
          document.getElementById("passwordLabel").style.display = "none";
          document.getElementById("success").style.display = "block";
          
}
function Language(){
  alert("Feature Not Available Now, or Ever.");
}