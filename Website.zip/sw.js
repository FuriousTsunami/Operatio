const staticCacheName = "staticCache";
const assets = [
  "/",
  "/index.html",
  "/CSS/style.css",
  "/CSS/w3.css",
  "/Images/Icon-72.png",
  "/JavaScript/app.js",
  "/JavaScript/ui.js",
  "/Pages/aboutUs.html"
  "/Pages/explore.html",
  "/Pages/favorites.html",
  "/Pages/getStarted.html",
  "/Pages/settings.html",
  "/Pages/signIn.html",
  "/manifest.json",
]

self.addEventListener('install', evt => {
  //console.log('service worker installed');
  evt.waitUntil(
    caches.open(staticCacheName).then((cache) => {
      console.log("Caching Assets");
      cache.addAll(assets);
    })
  );
});
self.addEventListener('activate', evt => {
  console.log('service worker activated');
  evt.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(keys
        .filter(key => key !== staticCacheName)
        .map(key => caches.delete(key))
      );
    })
  );
});

self.addEventListener("fetch", fetchEvent => {
  fetchEvent.respondWith(
    caches.match(fetchEvent.request).then(res => {
      return fetch(fetchEvent.request) || res;
    })
  )
})